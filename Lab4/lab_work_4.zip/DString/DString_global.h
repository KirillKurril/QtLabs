#ifndef DSTRING_GLOBAL_H
#define DSTRING_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(DSTRING_LIBRARY)
#  define DSTRING_EXPORT Q_DECL_EXPORT
#else
#  define DSTRING_EXPORT Q_DECL_IMPORT
#endif

#endif // DSTRING_GLOBAL_H
