#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit->text();
    int n = text.toInt();
    str1.memcpy(&(str1[0]),&(str2[0]), n);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_3_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit_2->text();
    int n = text.toInt();
    str1.memmove(&(str1[0]),&(str2[0]), n);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_5_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    str1.strcpy(str1, str2);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_7_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit_3->text();
    int n = text.toInt();
    str1.strncpy(str1,str2, n);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_9_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    str1.strcat(str1, str2);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_11_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit_10->text();
    int n = text.toInt();
    str1.strncat(str1,str2, n);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_12_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    ui->lineEdit_11->setText(QString::number(str1.strcmp(str1, str2)));
}


void MainWindow::on_pushButton_2_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit_6->text();
    int n = text.toInt();
    ui->lineEdit_7->setText(QString::number(str1.strncmp(str1, str2, n)));
}




void MainWindow::on_pushButton_10_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    ui->lineEdit_9->setText(QString::number(str1.strlen()));
    ui->lineEdit_12->setText(QString::number(str2.strlen()));
}


void MainWindow::on_pushButton_6_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    DString str1(s1.toStdString().c_str());
    QString text = ui->lineEdit_13->text();
    int n = text.toInt();
    int k = (ui->lineEdit_14->text()).toInt();
    str1.memset(str1, n, k);
    ui->textEdit->setPlainText(str1.c_str());
}


void MainWindow::on_pushButton_8_clicked()
{
    DString str1;
    int n = ui->lineEdit_5->text().toInt();

    ui->lineEdit_8->setText((str1.strerror(n)).c_str());
}



void MainWindow::on_pushButton_13_clicked()
{
    QString s1 = ui->textEdit->toPlainText();
    QString s2 = ui->textEdit_2->toPlainText();
    DString str1(s1.toStdString().c_str());
    DString str2(s2.toStdString().c_str());
    QString text = ui->lineEdit_15->text();
    int n = text.toInt();
     ui->lineEdit_4->setText(QString::number(str1.memcmp(str1, str2, n)));
}


void MainWindow::on_pushButton_4_clicked()
{
//    QString s1 = ui->textEdit->toPlainText();
//    DString str1(s1.toStdString().c_str());
//    QString text = ui->lineEdit_15->text();
//    const char* symb = text.toStdString().c_str();
//    char* token = strtok(str1.c_str(),*symb);
//    while (token != NULL) {
//            s1 += token;
//            token = strtok(NULL, *symb);
//        }
//    ui->textEdit->setPlainText(s1.toStdString().c_str());
}

